
package mysql_conexion;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;

public class Procedures {
    private static Connection conexion;
    private static String bd="Drogueria";
    private static String user="root";
    private static String password="1234";
    private static String host="localhost";
    private static String server="jdbc:mysql://"+host+"/"+bd;
    private Connection conn = null;
    
    public Procedures(){
        try{         
            Class.forName("com.mysql.jdbc.Driver");         
            conn = DriverManager.getConnection(server,user,password);         
        }catch(SQLException e){
         System.out.println(e);
        }catch(ClassNotFoundException e){
         System.out.println(e);
        }
        }
    public String Reservar(String cantidad,String fecha_inicial,String fecha_final,int cedula,int med_id,int pro_id,int turno){    
            String resultado="Reserva realizada";
            try {            
            // se crea instancia a procedimiento, los parametros de entrada y salida se simbolizan con el signo ?
            CallableStatement proc = conn.prepareCall(" call reserva()");
            //se cargan los parametros de entrada
            proc.setString("nombre", cantidad);//Tipo String
            proc.setString("fecha_inicial",fecha_inicial);//Tipo date
            proc.setString("fecha_Final",fecha_final);//Tipo date
            proc.setInt("cedula",cedula);//Tipo String
            proc.setInt("med_id", med_id);//Tipo entero
            proc.setInt("pro_id",pro_id);//Tipo entero
            proc.setInt("turno",turno);//Tipo entero
            // Se ejecuta el procedimiento almacenado
            proc.execute();            
            } 
            catch (Exception e) {                  
            System.out.println(e);
            }
            return resultado;
    }
    public String Vender(String fecha,int cedula,int id_empleado,String tipo,int id,int cantidad ){
            String resultado="Accion realizada";
            try {
            CallableStatement proc = conn.prepareCall("call vender()");
            proc.setString("fecha_inicial",fecha);
            proc.setInt("cedula",cedula);
            proc.setInt("id_empleado",id_empleado);
            proc.setString("tipo",tipo);
            proc.setInt("id",id);
            proc.setInt("cantidad",cantidad);
            } 
            catch (Exception e) {                  
            System.out.println(e);
            }
            return resultado;
    };
    
    public String[] Masven(String fecha){
            String res = null;
            String res2= null;
            String[] Res=new String[2]; 
            try {
            CallableStatement proc = conn.prepareCall("call MasVend()");
            proc.setString("ifecha",fecha);//Tipo date
            proc.registerOutParameter("maxmed", Types.VARCHAR);//Tipo String
            res = proc.getString("maxmed");
            proc.registerOutParameter("minmed", Types.VARCHAR);//Tipo String
            res2 = proc.getString("minmed");
            Res [0]=res;
            Res [1]=res2;
            } 
            catch (Exception e) {                  
            System.out.println(e);
            }
            return Res;
    };
    
    public String idmed(String nombre){
            String desc=null;
            int id =1;
            try {
            CallableStatement proc = conn.prepareCall("call med()");
            proc.setString("nombre",nombre);
            proc.registerOutParameter("id", Types.VARCHAR);//Tipo String
            id = proc.getInt("id");
            Procedures rv = new Procedures();
            desc=rv.DescMed(id);
            } 
            catch (Exception e) {                  
            System.out.println(e);
            }
            return desc;
    };
    
    public String DescMed(int id){
           String res = null;
           try {
            CallableStatement proc = conn.prepareCall("call MasVend()");
            proc.setInt("id",id);//Tipo dateb
            proc.registerOutParameter("des", Types.VARCHAR);//Tipo String
            res = proc.getString("des");
            } 
            catch (Exception e) {                  
            System.out.println(e);
            }
           return res;
    };
}
