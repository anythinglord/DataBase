
package mysql_conexion;

public class NewClass {
    
}
