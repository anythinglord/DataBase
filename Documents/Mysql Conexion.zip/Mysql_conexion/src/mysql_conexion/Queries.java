
package mysql_conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Queries {
    private static Connection conexion;
    private static String bd="Drogueria";
    private static String user="root";
    private static String password="1234";
    private static String host="localhost";
    private static String server="jdbc:mysql://"+host+"/"+bd;
    private Connection conn = null;
    public static String prestigio,fecha;
    public static int cedula;
    
    public Queries(){
        //conectar
        try {
        Class.forName("com.mysql.jdbc.Driver");
        conexion = DriverManager.getConnection(server, user, password);
        System.out.println("Conexión a base de datos " + server + " ... OK");
        } catch (ClassNotFoundException ex) {
        System.out.println("Error cargando el Driver MySQL JDBC ... FAIL");
        } catch (SQLException ex) {
        System.out.println("Imposible realizar conexion con "+server+" ... FAIL");
        }}
        
    public static int[] infoRerseva(String fecha){
        int[] info=new int[2];    
        try {
        // Preparamos la consulta
        Statement s = conexion.createStatement();
        ResultSet rs = s.executeQuery ("select per_cedula,fecha_ini_res from reservar where res_id = " + fecha );
        // Recorremos el resultado, mientras haya registros para leer, y escribimos
        //el resultado en pantalla.
        while (rs.next()){
        System.out.println("Exp_id:" +rs.getInt (1) + "," +"Exp_nombre:" +rs.getString (2));
        fecha = rs.getString (2);
        cedula = rs.getInt (1);
        info[0]=rs.getInt(1); //cedula de la persona
        info[1]=rs.getInt(2); //id de la persona
        }
        } catch (SQLException ex) {
        System.out.println("Imposible realizar consulta ... FAIL");
        }
        return info;
    };
    
    public static int[] Prestige(String nombre){
        int[] Return = new int[2];
        try {
        // Preparamos la consulta
        Statement s = conexion.createStatement();
        ResultSet rs = s.executeQuery ("select per_nombre,cli_prestigio from cliente natural join persona where per_cedula = " + nombre);
        // Recorremos el resultado, mientras haya registros para leer, y escribimos
        //el resultado en pantalla.
        while (rs.next()){
        System.out.println("Cli_id:" +rs.getString (1) + "," +"Cli_prestigio:" +rs.getString (2));
        prestigio = rs.getString(2);
        System.out.println(rs.getString(2));
        Return[0]=rs.getInt(1); // cedula de la persona
        Return[1]=rs.getInt(2); //cedula de l
        
        }
        } catch (SQLException ex) {
        System.out.println("Imposible realizar consulta ... FAIL");
        }
        return Return;
    }
}
    


