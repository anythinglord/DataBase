
package mysql_conexion;
import java.sql.*;
import java.util.Date;

public class Mysql_conexion {
    
    
    public static void main(String[] args) {
        
        Login.main(null);
        
    //Procedures     
        //Realizar reservas
        // fecha se debe ingresar "aaaa-mm-dd"
        Procedures rv = new Procedures();
        String r=null; 
        // r= rv.Procedures("cantidad","fecha_inicial","fecha_final","cedula","med_id","pro_id","turno");
        System.out.println(r);
        
        // Vender Producto o medicamento
        // fecha se debe ingresar "aaaa-mm-dd"
        String a=null;
        // la linea de abajo se decomenta y se insertan los datos
        //a= rv.Vender("fecha","cedula persona","id_empleado","tipo (producto o medicamento)","id","cantidad");
        System.out.println(a);
        
        //producto mas vendido y menos vendido
        //en la posicion 0 del arreglo esta el prod mas vendido
        //en la posicion 0 del arreglo esta el prod menos vendido
        String[] b = new String[2];
        b = rv.Masven("fecha") ; 
        System.out.println(b);
        
        //Descripcion del producto 
        String c=null;
        // a linea de abajo se decomenta y se insertan los datos
        // c= rv.idmed("id del medicamento")
        System.out.println(b);
        
    //Consultas
        
        //consultar el id de la reserva y cedula de quien la realiza
        Queries q = new Queries();
        int[] m = new int[2];
        m=q.infoRerseva("fecha");
        System.out.println(m);
        
        //consultar el presrigio y la cedula de los empleados 
        int[] n = new int[2];
        n = q.Prestige("karen");
        System.out.println(n);
    }
    
}
